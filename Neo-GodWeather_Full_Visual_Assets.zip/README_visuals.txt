Instructions:
1. Upload icon.png and splash.jpg to your GitHub repo under /assets/
2. Update your app’s main UI loader to reference:
   - icon.png for launcher
   - splash.jpg for pre-load screen
3. Commit message:
   🎨 Added Spotify-style icon and splash screen (Neo – v2.3.2)
