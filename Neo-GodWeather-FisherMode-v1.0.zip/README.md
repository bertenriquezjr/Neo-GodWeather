# Neo-GodWeather (Fisherman Mode)

Final build with 4-week marine forecast: wind, tide, visibility.
Includes bilingual UI, fishing log, and zone selector.