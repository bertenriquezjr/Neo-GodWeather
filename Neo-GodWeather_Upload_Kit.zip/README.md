# Neo-GodWeather
AI-enhanced symbolic weather forecast system for LGUs and IRRI.

Includes attribution, encryption metadata, and release binaries.