
# Neo-GodWeather (by Neo / Bert Enriquez Jr)

## 🌾 Farmer Mode (God Mode Build)
- ✅ 4-week rainfall forecast with 95% confidence
- 🌱 Localized province selector (Bulacan, Bataan, etc.)
- 🗣 Tagalog/English language switcher
- 📓 Farmer feedback form for offline notes
- ⚠️ Privacy-first, no tracking

## 🎣 Fisherman Mode
- ✅ 28-day sea condition forecasts
- 🌊 Displays wind (km/h), tide (m), and sea status
- 📍 Coastal region selector (Zambales, Baler, etc.)
- 🗣 Tagalog/English support
- ⚓ Fisherfolk journal (field logs)

> Designed for IRRI, PAGASA, LGUs, and individual use. Fully offline-friendly with PWA features.
